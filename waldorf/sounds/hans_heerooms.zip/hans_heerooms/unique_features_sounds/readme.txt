Patches for the Microwave XT by HansH

These patches are to show some unusual (and maybe unusable !) soundtricks on the XT

ARPFMFILT.MID :

Arpeggiator with sync LFO to FM Filter

DELAYBELL.MID :

Delayed Bell sound : the delaytime is controlled by the filter attacktime. This sound shows what can be done with the differentiate function in the modmatrix. Play long and short notes !

EEN23.MID :

Probably everyone has a weird patch with the 1-2-3-4-5 wavetable, this one is mine ! Notice the use of the lfo to the noise to get an extra rythm. Start first with pressing just C1 !

TALK.MID :

I have been playing around with the IPOX speech synth from Philip Pilgrim's
site . Result : A wavetable (made with the aid of SD) saying: "Microwave".
Attached a midifile with waves,wavetable and a demopatch. The quality of the
speech is acceptable, it seems that IPOX is very usable for creating
wavetables.

TIBETARR.MID :

In this Booming Techno Era this MULTI shows the more experimental side of the XT. Press just C3 and wait at least a minute to hear the monks of Tibet chanting ,hitting their bells and blowing their horns. Anyone still likes samplers ??


Regards,

Hans Heerooms
